import { useState } from 'react'
import LandingPage from './pages/LandingPage'
import LoginPage from './pages/LoginPage'
import SignupPage from './pages/SignupPage'
import Dashboard from './pages/Dashboard'
import './App.css'

function App() {
  const CURRENT_USER_KEY = 'waterChallengeCurrentUser'

  const getCurrentUser = () => {
    try {
      return JSON.parse(localStorage.getItem(CURRENT_USER_KEY)) || null
    } catch (error) {
      return null
    }
  }

  const savedUser = getCurrentUser()

  const [currentPage, setCurrentPage] = useState(savedUser ? 'dashboard' : 'landing')
  const [user, setUser] = useState(savedUser)

  const handleNavigate = (page) => {
    if (page === 'dashboard' && !user) {
      setCurrentPage('login')
      return
    }

    setCurrentPage(page)
  }

  const handleLogin = (userData) => {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(userData))
    setUser(userData)
    setCurrentPage('dashboard')
  }

  const handleLogout = () => {
    localStorage.removeItem(CURRENT_USER_KEY)
    setUser(null)
    setCurrentPage('landing')
  }

  return (
    <div className="app">
      {currentPage === 'landing' && (
        <LandingPage onNavigate={handleNavigate} />
      )}

      {currentPage === 'login' && (
        <LoginPage
          onNavigate={handleNavigate}
          onLogin={handleLogin}
        />
      )}

      {currentPage === 'signup' && (
        <SignupPage
          onNavigate={handleNavigate}
          onSignup={handleLogin}
        />
      )}

      {currentPage === 'dashboard' && user && (
        <Dashboard
          user={user}
          onLogout={handleLogout}
          onNavigate={handleNavigate}
        />
      )}
    </div>
  )
}

export default App
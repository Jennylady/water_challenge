import { useState, useRef } from 'react'
import { motion } from 'framer-motion'
import './SignupPage.css'

function SignupPage({ onNavigate, onSignup }) {
  const [language, setLanguage] = useState('FR')
  const [currentStep, setCurrentStep] = useState(1)
  const [message, setMessage] = useState({ type: '', text: '' })
  const formRef = useRef(null)

  const USERS_STORAGE_KEY = 'waterChallengeUsers'

  const initialFormData = {
    nom: '',
    prenom: '',
    email: '',
    motDePasse: '',
    confirmationMotDePasse: '',
    telephone: '',
    dateNaissance: '',
    scoutType: '',
    section: '',
    sampana: '',
    position: '',
    fivondronana: '',
    faritra: '',
    diosezy: '',
  }

  const [formData, setFormData] = useState(initialFormData)

  const scoutOptions = {
    FR: [
      { value: 'fanilon', label: "Fanilon'i Madagasikara" },
      { value: 'mpanazavan', label: "Mpanazavan'I Madagasikara" },
      { value: 'kiadin', label: "Kiadin'I Madagasikara" },
      { value: 'antilin', label: "Antilin'i Madagasikara" },
      { value: 'tilin', label: "Tilin'i Madagasikara" },
      { value: 'non-scout', label: 'Je ne suis pas scout' },
      { value: 'autre', label: 'Autre' },
    ],
    MLG: [
      { value: 'fanilon', label: "Fanilon'i Madagasikara" },
      { value: 'mpanazavan', label: "Mpanazavan'I Madagasikara" },
      { value: 'kiadin', label: "Kiadin'I Madagasikara" },
      { value: 'antilin', label: "Antilin'i Madagasikara" },
      { value: 'tilin', label: "Tilin'i Madagasikara" },
      { value: 'non-scout', label: 'Tsy scout aho' },
      { value: 'autre', label: 'Hafa' },
    ],
  }

  const sections = {
    FR: {
      mavo: 'Bleu (Mavo)',
      maitso: 'Vert (Maitso)',
      mena: 'Rouge (Mena)',
      cheftaine: 'Cheftaine',
    },
    MLG: {
      mavo: 'Bleu (Mavo)',
      maitso: 'Vert (Maitso)',
      mena: 'Rouge (Mena)',
      cheftaine: 'Cheftaine',
    },
  }

  const positions = {
    FR: {
      cheftaine: 'Cheftaine',
      tonia: 'Tonia',
      filoha: 'Filoha',
      beazina: 'Beazina',
      enleve: 'Élève',
    },
    MLG: {
      cheftaine: 'Cheftaine',
      tonia: 'Tonia',
      filoha: 'Filoha',
      beazina: 'Beazina',
      enleve: 'Mpianatra',
    },
  }

  const content = {
    FR: {
      title: 'Créer un compte',
      step1: 'Informations personnelles',
      step2: 'Informations de scout',
      step3: 'Localisation',

      nomLabel: 'Nom',
      prenomLabel: 'Prénom',
      emailLabel: 'Email',
      passwordLabel: 'Mot de passe',
      confirmPasswordLabel: 'Confirmer le mot de passe',
      telephoneLabel: 'Téléphone',
      dateNaissanceLabel: 'Date de naissance',

      scoutTypeLabel: 'Guide et Scout',
      sectionLabel: 'Section (Sampana)',
      positionLabel: 'Position',

      fivondronanaLabel: 'Fivondronana (District)',
      faritraLabel: 'Faritra (Région)',
      diosezLabel: 'Diosezy (Diocèse)',

      nextBtn: 'Suivant',
      backBtn: 'Retour',
      signupBtn: "S'inscrire",
      loginLink: 'Vous avez déjà un compte ? Se connecter',
      selectOption: 'Choisir une option',

      passwordPlaceholder: 'Minimum 6 caractères',
      confirmPasswordPlaceholder: 'Confirmer le mot de passe',

      requiredError: 'Veuillez remplir tous les champs obligatoires.',
      passwordLengthError: 'Le mot de passe doit contenir au moins 6 caractères.',
      passwordMatchError: 'Les mots de passe ne correspondent pas.',
      emailExistError: 'Un compte existe déjà avec cet email.',
      successMessage: 'Compte créé avec succès.',
    },

    MLG: {
      title: 'Famoronana kaonty',
      step1: 'Fampahalalana momba ny tena',
      step2: 'Fampahalalana momba ny Scout',
      step3: 'Toerana',

      nomLabel: 'Anarana',
      prenomLabel: 'Fanampin’anarana',
      emailLabel: 'Email',
      passwordLabel: 'Teny miafina',
      confirmPasswordLabel: 'Hamafiso ny teny miafina',
      telephoneLabel: 'Telefôna',
      dateNaissanceLabel: 'Andro nahaterahana',

      scoutTypeLabel: 'Guide sy Scout',
      sectionLabel: 'Sampana',
      positionLabel: 'Toerana andraikitra',

      fivondronanaLabel: 'Fivondronana',
      faritraLabel: 'Faritra',
      diosezLabel: 'Diosezy',

      nextBtn: 'Manaraka',
      backBtn: 'Miverina',
      signupBtn: 'Hisoratra',
      loginLink: 'Manana kaonty ve ? Hiditra',
      selectOption: 'Misafidiana',

      passwordPlaceholder: 'Tarehintsoratra 6 farafahakeliny',
      confirmPasswordPlaceholder: 'Hamafiso ny teny miafina',

      requiredError: 'Fenoy daholo ireo saha ilaina.',
      passwordLengthError: 'Tsy maintsy manana tarehintsoratra 6 farafahakeliny ny teny miafina.',
      passwordMatchError: 'Tsy mitovy ny teny miafina.',
      emailExistError: 'Efa misy kaonty mampiasa io email io.',
      successMessage: 'Vita soa aman-tsara ny fisoratana.',
    },
  }

  const t = content[language]

  const showMessage = (type, text) => {
    setMessage({ type, text })
  }

  const clearMessage = () => {
    setMessage({ type: '', text: '' })
  }

  const handleChange = (e) => {
    const { name, value } = e.target

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))

    clearMessage()
  }

  const getSavedUsers = () => {
    try {
      return JSON.parse(localStorage.getItem(USERS_STORAGE_KEY)) || []
    } catch (error) {
      return []
    }
  }

  const saveUsers = (users) => {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users))
  }

  const validateStepOne = () => {
    const requiredFields = [
      formData.nom,
      formData.prenom,
      formData.email,
      formData.motDePasse,
      formData.confirmationMotDePasse,
      formData.telephone,
      formData.dateNaissance,
    ]

    const hasEmptyField = requiredFields.some((field) => !field.trim())

    if (hasEmptyField) {
      showMessage('error', t.requiredError)
      return false
    }

    if (formData.motDePasse.length < 6) {
      showMessage('error', t.passwordLengthError)
      return false
    }

    if (formData.motDePasse !== formData.confirmationMotDePasse) {
      showMessage('error', t.passwordMatchError)
      return false
    }

    return true
  }

  const validateStepTwo = () => {
    if (!formData.scoutType || !formData.section || !formData.position) {
      showMessage('error', t.requiredError)
      return false
    }

    return true
  }

  const validateStepThree = () => {
    if (!formData.faritra.trim() || !formData.fivondronana.trim()) {
      showMessage('error', t.requiredError)
      return false
    }

    return true
  }

  const validateCurrentStep = () => {
    clearMessage()

    if (formRef.current && !formRef.current.reportValidity()) {
      return false
    }

    if (currentStep === 1) return validateStepOne()
    if (currentStep === 2) return validateStepTwo()
    if (currentStep === 3) return validateStepThree()

    return true
  }

  const validateAllSteps = () => {
    if (!validateStepOne()) {
      setCurrentStep(1)
      return false
    }

    if (!validateStepTwo()) {
      setCurrentStep(2)
      return false
    }

    if (!validateStepThree()) {
      setCurrentStep(3)
      return false
    }

    return true
  }

  const handleNextStep = () => {
    if (!validateCurrentStep()) return
    setCurrentStep((prev) => prev + 1)
  }

  const handlePreviousStep = () => {
    clearMessage()
    setCurrentStep((prev) => prev - 1)
  }

  const resetForm = () => {
    setFormData(initialFormData)
    setCurrentStep(1)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    clearMessage()

    if (!validateAllSteps()) return

    const savedUsers = getSavedUsers()
    const cleanEmail = formData.email.trim().toLowerCase()

    const emailAlreadyExists = savedUsers.some(
      (user) => user.email?.trim().toLowerCase() === cleanEmail
    )

    if (emailAlreadyExists) {
      showMessage('error', t.emailExistError)
      setCurrentStep(1)
      return
    }

    const newUser = {
      id: Date.now(),
      nom: formData.nom.trim(),
      prenom: formData.prenom.trim(),
      email: cleanEmail,
      motDePasse: formData.motDePasse,
      telephone: formData.telephone.trim(),
      dateNaissance: formData.dateNaissance,
      scoutType: formData.scoutType,
      section: formData.section,
      sampana: formData.sampana,
      position: formData.position,
      fivondronana: formData.fivondronana.trim(),
      faritra: formData.faritra.trim(),
      diosezy: formData.diosezy.trim(),
      createdAt: new Date().toISOString(),
    }

    const updatedUsers = [...savedUsers, newUser]
    saveUsers(updatedUsers)

    const connectedUser = {
      id: newUser.id,
      nom: newUser.nom,
      prenom: newUser.prenom,
      email: newUser.email,
      telephone: newUser.telephone,
      dateNaissance: newUser.dateNaissance,
      scoutType: newUser.scoutType,
      section: newUser.section,
      sampana: newUser.sampana,
      position: newUser.position,
      fivondronana: newUser.fivondronana,
      faritra: newUser.faritra,
      diosezy: newUser.diosezy,
      connectedAt: new Date().toISOString(),
    }

    showMessage('success', t.successMessage)
    resetForm()

    if (onSignup) {
      onSignup(connectedUser)
    } else {
      onNavigate('login')
    }
  }

  return (
    <div className="signup-page">
      <motion.button
        className="back-arrow-btn"
        onClick={() => onNavigate('landing')}
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
        type="button"
        title="Retour"
      >
        ←
      </motion.button>

      <motion.div
        className="signup-container"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.65, delay: 0.2 }}
      >
        <div className="signup-box">
          <div className="form-header">
            <div className="signup-logo" onClick={() => onNavigate('landing')}>
              <span className="signup-logo-mark">W</span>
              <span>Water Challenge</span>
            </div>

            <div className="signup-language">
              <button
                type="button"
                className={language === 'FR' ? 'active' : ''}
                onClick={() => setLanguage('FR')}
              >
                FR
              </button>

              <button
                type="button"
                className={language === 'MLG' ? 'active' : ''}
                onClick={() => setLanguage('MLG')}
              >
                MLG
              </button>
            </div>
          </div>

          <h1>{t.title}</h1>

          <div className="signup-progress">
            <div className={`progress-step ${currentStep >= 1 ? 'active' : ''}`}>
              <span>1</span>
              <p>{t.step1}</p>
            </div>

            <div className={`progress-step ${currentStep >= 2 ? 'active' : ''}`}>
              <span>2</span>
              <p>{t.step2}</p>
            </div>

            <div className={`progress-step ${currentStep >= 3 ? 'active' : ''}`}>
              <span>3</span>
              <p>{t.step3}</p>
            </div>
          </div>

          {message.text && (
            <div className={`signup-message ${message.type}`}>
              {message.text}
            </div>
          )}

          <form ref={formRef} onSubmit={handleSubmit} className="signup-form">
            {currentStep === 1 && (
              <motion.div
                className="form-step"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
              >
                <div className="form-row">
                  <div className="form-group">
                    <label>{t.nomLabel}</label>
                    <input
                      type="text"
                      name="nom"
                      value={formData.nom}
                      onChange={handleChange}
                      placeholder="Dupont"
                      required
                    />
                  </div>

                  <div className="form-group">
                    <label>{t.prenomLabel}</label>
                    <input
                      type="text"
                      name="prenom"
                      value={formData.prenom}
                      onChange={handleChange}
                      placeholder="Jean"
                      required
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label>{t.emailLabel}</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="email@example.com"
                    required
                  />
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>{t.passwordLabel}</label>
                    <input
                      type="password"
                      name="motDePasse"
                      value={formData.motDePasse}
                      onChange={handleChange}
                      placeholder={t.passwordPlaceholder}
                      minLength="6"
                      required
                    />
                  </div>

                  <div className="form-group">
                    <label>{t.confirmPasswordLabel}</label>
                    <input
                      type="password"
                      name="confirmationMotDePasse"
                      value={formData.confirmationMotDePasse}
                      onChange={handleChange}
                      placeholder={t.confirmPasswordPlaceholder}
                      minLength="6"
                      required
                    />
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>{t.telephoneLabel}</label>
                    <input
                      type="tel"
                      name="telephone"
                      value={formData.telephone}
                      onChange={handleChange}
                      placeholder="+261 XX XXX XXXX"
                      required
                    />
                  </div>

                  <div className="form-group">
                    <label>{t.dateNaissanceLabel}</label>
                    <input
                      type="date"
                      name="dateNaissance"
                      value={formData.dateNaissance}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {currentStep === 2 && (
              <motion.div
                className="form-step"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
              >
                <div className="form-group">
                  <label>{t.scoutTypeLabel}</label>
                  <select
                    name="scoutType"
                    value={formData.scoutType}
                    onChange={handleChange}
                    required
                  >
                    <option value="">{t.selectOption}</option>

                    {scoutOptions[language].map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>{t.sectionLabel}</label>
                    <select
                      name="section"
                      value={formData.section}
                      onChange={handleChange}
                      required
                    >
                      <option value="">{t.selectOption}</option>

                      {Object.entries(sections[language]).map(([key, val]) => (
                        <option key={key} value={key}>
                          {val}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="form-group">
                    <label>{t.positionLabel}</label>
                    <select
                      name="position"
                      value={formData.position}
                      onChange={handleChange}
                      required
                    >
                      <option value="">{t.selectOption}</option>

                      {Object.entries(positions[language]).map(([key, val]) => (
                        <option key={key} value={key}>
                          {val}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </motion.div>
            )}

            {currentStep === 3 && (
              <motion.div
                className="form-step"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
              >
                <div className="form-group">
                  <label>{t.faritraLabel}</label>
                  <input
                    type="text"
                    name="faritra"
                    value={formData.faritra}
                    onChange={handleChange}
                    placeholder="Ex: Analamanga"
                    required
                  />
                </div>

                <div className="form-group">
                  <label>{t.fivondronanaLabel}</label>
                  <input
                    type="text"
                    name="fivondronana"
                    value={formData.fivondronana}
                    onChange={handleChange}
                    placeholder="Ex: Antananarivo"
                    required
                  />
                </div>

                <div className="form-group">
                  <label>{t.diosezLabel}</label>
                  <input
                    type="text"
                    name="diosezy"
                    value={formData.diosezy}
                    onChange={handleChange}
                    placeholder="Ex: Antananarivo"
                  />
                </div>
              </motion.div>
            )}

            <div className="form-buttons">
              {currentStep > 1 && (
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={handlePreviousStep}
                >
                  {t.backBtn}
                </button>
              )}

              {currentStep < 3 && (
                <button
                  type="button"
                  className="btn-primary"
                  onClick={handleNextStep}
                >
                  {t.nextBtn}
                </button>
              )}

              {currentStep === 3 && (
                <button type="submit" className="btn-primary">
                  {t.signupBtn}
                </button>
              )}
            </div>
          </form>

          <div className="signup-footer">
            <button
              type="button"
              className="link-btn"
              onClick={() => onNavigate('login')}
            >
              {t.loginLink}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  )
}

export default SignupPage